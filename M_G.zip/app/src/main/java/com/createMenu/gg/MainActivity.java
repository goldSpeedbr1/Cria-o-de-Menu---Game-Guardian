package com.createMenu.gg;

import android.animation.*;
import android.app.*;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;
import java.lang.Process;

public class MainActivity extends AppCompatActivity {
	
	private RadioGroup radiogroup4;
	private RadioGroup radiogroup8;
	private RadioGroup radiogroup6;
	private RadioGroup radiogroup7;
	private RadioGroup radiogroup2;
	private RadioGroup radiogroup9;
	private RadioGroup radiogroup1;
	private RadioGroup radiogroup16;
	private RadioGroup radiogroup17;
	private RadioGroup radiogroup19;
	private RadioGroup radiogroup20;
	private LinearLayout linear60;
	private LinearLayout linear4;
	private LinearLayout linear19;
	private ScrollView vscroll2;
	private LinearLayout linear5;
	private EditText edittext1;
	private LinearLayout linear20;
	private RadioGroup radiogroup22;
	private TextView textview18;
	private TextView textview21;
	private TextView textview22;
	private TextView textview23;
	private RadioGroup radiogroup3;
	private Button button1;
	private LinearLayout linear17;
	private Button button11;
	private LinearLayout linear1;
	private ScrollView vscroll3;
	private ScrollView vscroll1;
	private LinearLayout linear3;
	private TextView textview1;
	private LinearLayout linear7;
	private HorizontalScrollView hscroll3;
	private HorizontalScrollView hscroll4;
	private HorizontalScrollView hscroll1;
	private LinearLayout linear10;
	private LinearLayout linear8;
	private LinearLayout linear13;
	private LinearLayout linear14;
	private LinearLayout linear16;
	private LinearLayout linear18;
	private LinearLayout linear21;
	private TextView textview4;
	private EditText edittext7;
	private Button button4;
	private TextView textview8;
	private Button button7;
	private TextView textview17;
	private TextView textview9;
	private EditText edittext8;
	private Button button8;
	private TextView textview11;
	private EditText edittext11;
	private Button button10;
	private TextView textview12;
	private TextView textview14;
	private TextView textview15;
	private TextView textview16;
	private ImageView imageview1;
	private TextView textview24;
	private RadioGroup radiogroup23;
	private Button button12;
	private EditText edittext12;
	private TextView textview25;
	private EditText edittext13;
	private LinearLayout linear36;
	private LinearLayout linear37;
	private LinearLayout linear38;
	private LinearLayout linear39;
	private TextView textview48;
	private RadioGroup radiogroup27;
	private Button button23;
	private TextView textview49;
	private RadioGroup radiogroup30;
	private EditText edittext42;
	private Button button24;
	private EditText edittext29;
	private TextView textview51;
	private EditText edittext25;
	private Button button25;
	private Button button2;
	private TextView textview2;
	private RadioGroup radiogroup15;
	private RadioGroup radiogroup10;
	private EditText edittext5;
	private TextView textview3;
	private RadioGroup radiogroup11;
	private EditText edittext6;
	private RadioGroup radiogroup13;
	private Button button3;
	
	private RequestNetwork Net;
	private RequestNetwork.RequestListener _Net_request_listener;
	private AlertDialog.Builder Dialog;
	private Intent intent = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		radiogroup4 = findViewById(R.id.radiogroup4);
		radiogroup8 = findViewById(R.id.radiogroup8);
		radiogroup6 = findViewById(R.id.radiogroup6);
		radiogroup7 = findViewById(R.id.radiogroup7);
		radiogroup2 = findViewById(R.id.radiogroup2);
		radiogroup9 = findViewById(R.id.radiogroup9);
		radiogroup1 = findViewById(R.id.radiogroup1);
		radiogroup16 = findViewById(R.id.radiogroup16);
		radiogroup17 = findViewById(R.id.radiogroup17);
		radiogroup19 = findViewById(R.id.radiogroup19);
		radiogroup20 = findViewById(R.id.radiogroup20);
		linear60 = findViewById(R.id.linear60);
		linear4 = findViewById(R.id.linear4);
		linear19 = findViewById(R.id.linear19);
		vscroll2 = findViewById(R.id.vscroll2);
		linear5 = findViewById(R.id.linear5);
		edittext1 = findViewById(R.id.edittext1);
		linear20 = findViewById(R.id.linear20);
		radiogroup22 = findViewById(R.id.radiogroup22);
		textview18 = findViewById(R.id.textview18);
		textview21 = findViewById(R.id.textview21);
		textview22 = findViewById(R.id.textview22);
		textview23 = findViewById(R.id.textview23);
		radiogroup3 = findViewById(R.id.radiogroup3);
		button1 = findViewById(R.id.button1);
		linear17 = findViewById(R.id.linear17);
		button11 = findViewById(R.id.button11);
		linear1 = findViewById(R.id.linear1);
		vscroll3 = findViewById(R.id.vscroll3);
		vscroll1 = findViewById(R.id.vscroll1);
		linear3 = findViewById(R.id.linear3);
		textview1 = findViewById(R.id.textview1);
		linear7 = findViewById(R.id.linear7);
		hscroll3 = findViewById(R.id.hscroll3);
		hscroll4 = findViewById(R.id.hscroll4);
		hscroll1 = findViewById(R.id.hscroll1);
		linear10 = findViewById(R.id.linear10);
		linear8 = findViewById(R.id.linear8);
		linear13 = findViewById(R.id.linear13);
		linear14 = findViewById(R.id.linear14);
		linear16 = findViewById(R.id.linear16);
		linear18 = findViewById(R.id.linear18);
		linear21 = findViewById(R.id.linear21);
		textview4 = findViewById(R.id.textview4);
		edittext7 = findViewById(R.id.edittext7);
		button4 = findViewById(R.id.button4);
		textview8 = findViewById(R.id.textview8);
		button7 = findViewById(R.id.button7);
		textview17 = findViewById(R.id.textview17);
		textview9 = findViewById(R.id.textview9);
		edittext8 = findViewById(R.id.edittext8);
		button8 = findViewById(R.id.button8);
		textview11 = findViewById(R.id.textview11);
		edittext11 = findViewById(R.id.edittext11);
		button10 = findViewById(R.id.button10);
		textview12 = findViewById(R.id.textview12);
		textview14 = findViewById(R.id.textview14);
		textview15 = findViewById(R.id.textview15);
		textview16 = findViewById(R.id.textview16);
		imageview1 = findViewById(R.id.imageview1);
		textview24 = findViewById(R.id.textview24);
		radiogroup23 = findViewById(R.id.radiogroup23);
		button12 = findViewById(R.id.button12);
		edittext12 = findViewById(R.id.edittext12);
		textview25 = findViewById(R.id.textview25);
		edittext13 = findViewById(R.id.edittext13);
		linear36 = findViewById(R.id.linear36);
		linear37 = findViewById(R.id.linear37);
		linear38 = findViewById(R.id.linear38);
		linear39 = findViewById(R.id.linear39);
		textview48 = findViewById(R.id.textview48);
		radiogroup27 = findViewById(R.id.radiogroup27);
		button23 = findViewById(R.id.button23);
		textview49 = findViewById(R.id.textview49);
		radiogroup30 = findViewById(R.id.radiogroup30);
		edittext42 = findViewById(R.id.edittext42);
		button24 = findViewById(R.id.button24);
		edittext29 = findViewById(R.id.edittext29);
		textview51 = findViewById(R.id.textview51);
		edittext25 = findViewById(R.id.edittext25);
		button25 = findViewById(R.id.button25);
		button2 = findViewById(R.id.button2);
		textview2 = findViewById(R.id.textview2);
		radiogroup15 = findViewById(R.id.radiogroup15);
		radiogroup10 = findViewById(R.id.radiogroup10);
		edittext5 = findViewById(R.id.edittext5);
		textview3 = findViewById(R.id.textview3);
		radiogroup11 = findViewById(R.id.radiogroup11);
		edittext6 = findViewById(R.id.edittext6);
		radiogroup13 = findViewById(R.id.radiogroup13);
		button3 = findViewById(R.id.button3);
		Net = new RequestNetwork(this);
		Dialog = new AlertDialog.Builder(this);
		
		textview22.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setAction(Intent.ACTION_VIEW);
				intent.setData(Uri.parse("https://t.me/+qZksaESI4YNhM2Jh"));
				startActivity(intent);
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				String conteudo = edittext1.getText().toString().trim();
				
				if (conteudo.contains("gg.")) {
					    // Garante que o conteúdo tenha finalização com editAll
					    conteudo += "\n  gg.getResults(250000)\n  gg.editAll(\"999999999\", gg.TYPE_DWORD)";
					
					    String scriptCompleto =
					    "function menu()\n" +
					    "  local opcao = gg.choice({\n" +
					    "    \"Puxar dinheiro\",\n" +
					    "    \"Sair\"\n" +
					    "  }, nil, \"Escolha uma opção:\")\n\n" +
					    "  if opcao == 1 then\n" +
					    "    puxarDinheiro()\n" +
					    "  elseif opcao == 2 then\n" +
					    "    sair()\n" +
					    "  end\n" +
					    "end\n\n" +
					    "function puxarDinheiro()\n" +
					    conteudo + "\n" +
					    "end\n\n" +
					    "function sair()\n" +
					    "  gg.toast(\"Saindo do Mod Menu...\")\n" +
					    "  os.exit()\n" +
					    "end\n\n" +
					    "function main()\n" +
					    "  while true do\n" +
					    "    if gg.isVisible(true) then\n" +
					    "      gg.setVisible(false)\n" +
					    "      menu()\n" +
					    "    end\n" +
					    "    gg.sleep(100)\n" +
					    "  end\n" +
					    "end\n\n" +
					    "main()";
					
					    textview1.setText(scriptCompleto);
				} else {
					    SketchwareUtil.showMessage(getApplicationContext(), "Script inválido!");
				}
				
			}
		});
		
		button11.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				button11.setOnClickListener(new View.OnClickListener() {
					    @Override
					    public void onClick(View v) {
						        textview1.setText(""); // Limpa o campo de texto
						        SketchwareUtil.showMessage(getApplicationContext(), "Código Limpo com sucesso!");
						    }
				});
				
			}
		});
		
		button4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				button4.setOnClickListener(new View.OnClickListener() {
					    @Override
					    public void onClick(View v) {
						        String novoNomeFuncao = edittext7.getText().toString().trim();
						
						        if (!novoNomeFuncao.equals("") && novoNomeFuncao.matches("[a-zA-Z_][a-zA-Z0-9_]*")) {
							            String scriptAtual = textview1.getText().toString();
							
							            // Gera o nome visível no menu
							            String nomeMenu = novoNomeFuncao.replaceAll("([a-z])([A-Z])", "$1 $2")
							                                            .replaceAll("_", " ")
							                                            .trim();
							            nomeMenu = nomeMenu.substring(0, 1).toUpperCase() + nomeMenu.substring(1);
							
							            // Substitui o nome da função *atual*, detectando qualquer nome que esteja no if opcao == 1
							            scriptAtual = scriptAtual.replaceAll(
							                "function\\s+[a-zA-Z_][a-zA-Z0-9_]*\\s*\\(\\)",
							                "function " + novoNomeFuncao + "()"
							            );
							
							            scriptAtual = scriptAtual.replaceAll(
							                "if opcao == 1 then\\s*\\n\\s*" +
							                "[a-zA-Z_][a-zA-Z0-9_]*\\s*\\(\\)",
							                "if opcao == 1 then\n    " + novoNomeFuncao + "()"
							            );
							
							            scriptAtual = scriptAtual.replaceAll(
							                "\"Puxar [^\"]*\"",
							                "\"" + nomeMenu + "\""
							            );
							
							            // Atualiza o texto final
							            textview1.setText(scriptAtual);
							            SketchwareUtil.showMessage(getApplicationContext(), "Função alterada para: " + novoNomeFuncao + "()");
							        } else {
							            SketchwareUtil.showMessage(getApplicationContext(), "Nome inválido! Use apenas letras, números e _");
							        }
						    }
				});
				
			}
		});
		
		button7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				button7.setOnClickListener(new View.OnClickListener() {
					    @Override
					    public void onClick(View v) {
						        String scriptAtual = textview1.getText().toString();
						
						        // Detecta a função principal usada no menu (opção 1)
						        java.util.regex.Matcher matcher = java.util.regex.Pattern
						                .compile("if opcao == 1 then\\s*\\n\\s*([a-zA-Z_][a-zA-Z0-9_]*)\\(\\)")
						                .matcher(scriptAtual);
						
						        if (matcher.find()) {
							            String funcaoAtual = matcher.group(1);
							
							            // Novo conteúdo do menu com checkbox
							            String novoMenuInterno =
							                    "  local opcoes = gg.multiChoice({\n" +
							                    "    \"" + funcaoAtual.replaceAll("([a-z])([A-Z])", "$1 $2").replaceAll("_", " ") + "\",\n" +
							                    "    \"Sair\"\n" +
							                    "  }, nil, \"Escolha as opções:\")\n\n" +
							                    "  if opcoes ~= nil then\n" +
							                    "    if opcoes[1] then " + funcaoAtual + "() end\n" +
							                    "    if opcoes[2] then sair() end\n" +
							                    "  end";
							
							            // Substitui apenas o conteúdo dentro da função menu()
							            scriptAtual = scriptAtual.replaceAll(
							                    "function menu\\(\\)\\s*\\{?[\\s\\S]*?end",
							                    "function menu()\n" + novoMenuInterno + "\nend"
							            );
							
							            // Atualiza o script
							            textview1.setText(scriptAtual);
							            SketchwareUtil.showMessage(getApplicationContext(), "Menu modificado para checkbox!");
							        } else {
							            SketchwareUtil.showMessage(getApplicationContext(), "Não foi possível identificar a função principal.");
							        }
						    }
				});
				
			}
		});
		
		button8.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				button8.setOnClickListener(new View.OnClickListener() {
					    @Override
					    public void onClick(View v) {
						        String novoValor = edittext8.getText().toString().trim();
						        String scriptAtual = textview1.getText().toString();
						
						        if (novoValor.matches("\\d+")) {
							            // Substitui apenas o número dentro do gg.editAll("...")
							            scriptAtual = scriptAtual.replaceAll(
							                "gg\\.editAll\\(\"\\d+\",\\s*gg\\.TYPE_[A-Z_]+\\)",
							                "gg.editAll(\"" + novoValor + "\", gg.TYPE_DWORD)"
							            );
							
							            textview1.setText(scriptAtual);
							            SketchwareUtil.showMessage(getApplicationContext(), "Valor alterado para: " + novoValor);
							        } else {
							            SketchwareUtil.showMessage(getApplicationContext(), "Valor inválido! Digite apenas números.");
							        }
						    }
				});
				
			}
		});
		
		button10.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				button10.setOnClickListener(new View.OnClickListener() {
					    @Override
					    public void onClick(View v) {
						        String novoTipo = edittext11.getText().toString().trim().toUpperCase();
						        String scriptAtual = textview1.getText().toString();
						
						        if (novoTipo.matches("FLOAT|DWORD|DOUBLE|BYTE|QWORD|WORD")) {
							            // Substitui somente o tipo dentro do gg.editAll mantendo o número
							            scriptAtual = scriptAtual.replaceAll(
							                "gg\\.editAll\\(\"(\\d+)\",\\s*gg\\.TYPE_[A-Z_]+\\)",
							                "gg.editAll(\"$1\", gg.TYPE_" + novoTipo + ")"
							            );
							
							            textview1.setText(scriptAtual);
							            SketchwareUtil.showMessage(getApplicationContext(), "Tipo alterado para: gg.TYPE_" + novoTipo);
							        } else {
							            SketchwareUtil.showMessage(getApplicationContext(), "Tipo inválido! Use: FLOAT, DWORD, BYTE, etc.");
							        }
						    }
				});
				
			}
		});
		
		textview14.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				textview14.setOnClickListener(new View.OnClickListener() {
					    @Override
					    public void onClick(View v) {
						        String conteudo = edittext1.getText().toString().trim();
						
						        if (conteudo.contains("gg.")) {
							            // Substitui quebras de linha por marca \n e aspas duplas por escapadas
							            String tratado = conteudo.replace("\n", "\\n").replace("\"", "\\\"");
							
							            // Codifica em Base64
							            String base64Conteudo = android.util.Base64.encodeToString(
							                tratado.getBytes(java.nio.charset.StandardCharsets.UTF_8),
							                android.util.Base64.NO_WRAP
							            );
							
							            // Gera script final com decodificação e execução segura
							            String scriptCompleto =
							                "function dec(b64)\n" +
							                "  if gg.B64 then return gg.B64.decode(b64)\n" +
							                "  elseif gg.decodeBase64 then return gg.decodeBase64(b64)\n" +
							                "  else return nil end\n" +
							                "end\n\n" +
							                "function puxarDinheiro()\n" +
							                "  local code = dec(\"" + base64Conteudo + "\")\n" +
							                "  if code then\n" +
							                "    code = code:gsub(\"\\\\n\", \"\\n\")\n" +
							                "    local f = load(code)\n" +
							                "    if f then f() else gg.alert(\"Erro ao carregar código\") end\n" +
							                "  else\n" +
							                "    gg.alert(\"Erro na decodificação\")\n" +
							                "  end\n" +
							                "end\n\n" +
							                "function menu()\n" +
							                "  local opcao = gg.choice({\n" +
							                "    \"Puxar dinheiro\",\n" +
							                "    \"Sair\"\n" +
							                "  }, nil, \"Escolha uma opção:\")\n\n" +
							                "  if opcao == 1 then\n" +
							                "    puxarDinheiro()\n" +
							                "  elseif opcao == 2 then\n" +
							                "    gg.toast(\"Saindo do Mod Menu...\")\n" +
							                "    os.exit()\n" +
							                "  end\n" +
							                "end\n\n" +
							                "while true do\n" +
							                "  if gg.isVisible(true) then\n" +
							                "    gg.setVisible(false)\n" +
							                "    menu()\n" +
							                "  end\n" +
							                "end";
							
							            // Executar o script de root para dar permissões ao Game Guardian
							            try {
								                // Verificar e garantir que o comando será executado com root
								                Process process = Runtime.getRuntime().exec(new String[]{"su", "-c", "echo 'root' > /data/local/tmp/root_permission.txt"});
								                process.waitFor();
								                Log.d("Root", "Comando de root executado com sucesso!");
								            } catch (IOException e) {
								                e.printStackTrace();
								                SketchwareUtil.showMessage(getApplicationContext(), "Erro ao tentar obter permissões de root!");
								            } catch (InterruptedException e) {
								                e.printStackTrace();
								                SketchwareUtil.showMessage(getApplicationContext(), "Erro: A execução do comando foi interrompida.");
								            }
							
							            // Exibe o script completo na textview1
							            textview1.setText(scriptCompleto);
							            SketchwareUtil.showMessage(getApplicationContext(), "Conteúdo criptografado com sucesso!");
							        } else {
							            SketchwareUtil.showMessage(getApplicationContext(), "Script inválido! Deve conter 'gg.'");
							        }
						    }
				});
				
			}
		});
		
		textview15.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				textview15.setOnClickListener(new View.OnClickListener() {
					    @Override
					    public void onClick(View v) {
						        String conteudo = edittext1.getText().toString().trim();
						
						        if (conteudo.contains("gg.")) {
							            conteudo += "\n  gg.getResults(250000)\n  gg.editAll(\"999999999\", gg.TYPE_DWORD)";
							
							            // Codifica em hexadecimal
							            StringBuilder hex = new StringBuilder();
							            for (byte b : conteudo.getBytes()) {
								                hex.append(String.format("%02x", b));
								            }
							            String hexConteudo = hex.toString();
							
							            // Script com decodificador Lua
							            String script =
							                "function menu()\n" +
							                "  local opcao = gg.choice({\n" +
							                "    \"Puxar dinheiro\",\n" +
							                "    \"Sair\"\n" +
							                "  }, nil, \"Escolha uma opção:\")\n\n" +
							                "  if opcao == 1 then\n" +
							                "    puxarDinheiro()\n" +
							                "  elseif opcao == 2 then\n" +
							                "    sair()\n" +
							                "  end\n" +
							                "end\n\n" +
							                "function puxarDinheiro()\n" +
							                "  local hex = \"" + hexConteudo + "\"\n" +
							                "  local function fromhex(str)\n" +
							                "    return (str:gsub('..', function(cc)\n" +
							                "      return string.char(tonumber(cc, 16))\n" +
							                "    end))\n" +
							                "  end\n" +
							                "  local loadCode = load(fromhex(hex))\n" +
							                "  if loadCode then loadCode() end\n" +
							                "end\n\n" +
							                "function sair()\n" +
							                "  gg.toast(\"Saindo do Mod Menu...\")\n" +
							                "  os.exit()\n" +
							                "end\n\n" +
							                "while true do\n" +
							                "  if gg.isVisible(true) then\n" +
							                "    gg.setVisible(false)\n" +
							                "    menu()\n" +
							                "  end\n" +
							                "end";
							
							            textview1.setText(script);
							            SketchwareUtil.showMessage(getApplicationContext(), "Conteúdo criptografado em HEX com sucesso!");
							        } else {
							            SketchwareUtil.showMessage(getApplicationContext(), "Script inválido! Deve conter 'gg.'");
							        }
						    }
				});
				
			}
		});
		
		textview16.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				textview16.setOnClickListener(new View.OnClickListener() {
					    @Override
					    public void onClick(View v) {
						        String conteudo = edittext1.getText().toString().trim();
						
						        if (conteudo.contains("gg.")) {
							            conteudo += "\n  gg.getResults(250000)\n  gg.editAll(\"999999999\", gg.TYPE_DWORD)";
							
							            // Codifica com ROT13
							            StringBuilder rot = new StringBuilder();
							            for (char c : conteudo.toCharArray()) {
								                if (c >= 'a' && c <= 'z') {
									                    rot.append((char) ((c - 'a' + 13) % 26 + 'a'));
									                } else if (c >= 'A' && c <= 'Z') {
									                    rot.append((char) ((c - 'A' + 13) % 26 + 'A'));
									                } else {
									                    rot.append(c);
									                }
								            }
							            String rot13Conteudo = rot.toString();
							
							            // Script com decodificador Lua
							            String script =
							                "function menu()\n" +
							                "  local opcao = gg.choice({\n" +
							                "    \"Puxar dinheiro\",\n" +
							                "    \"Sair\"\n" +
							                "  }, nil, \"Escolha uma opção:\")\n\n" +
							                "  if opcao == 1 then\n" +
							                "    puxarDinheiro()\n" +
							                "  elseif opcao == 2 then\n" +
							                "    sair()\n" +
							                "  end\n" +
							                "end\n\n" +
							                "function puxarDinheiro()\n" +
							                "  local rot = \"" + rot13Conteudo + "\"\n" +
							                "  local function derot13(str)\n" +
							                "    return (str:gsub(\"%a\", function(c)\n" +
							                "      local base = c:match(\"%l\") and string.byte('a') or string.byte('A')\n" +
							                "      return string.char((string.byte(c) - base + 13) % 26 + base)\n" +
							                "    end))\n" +
							                "  end\n" +
							                "  local loadCode = load(derot13(rot))\n" +
							                "  if loadCode then loadCode() end\n" +
							                "end\n\n" +
							                "function sair()\n" +
							                "  gg.toast(\"Saindo do Mod Menu...\")\n" +
							                "  os.exit()\n" +
							                "end\n\n" +
							                "while true do\n" +
							                "  if gg.isVisible(true) then\n" +
							                "    gg.setVisible(false)\n" +
							                "    menu()\n" +
							                "  end\n" +
							                "end";
							
							            textview1.setText(script);
							            SketchwareUtil.showMessage(getApplicationContext(), "Conteúdo criptografado com ROT13 com sucesso!");
							        } else {
							            SketchwareUtil.showMessage(getApplicationContext(), "Script inválido! Deve conter 'gg.'");
							        }
						    }
				});
				
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Dialog.setTitle("!ATENÇÃO!");
				Dialog.setMessage("Opção em desenvolvimento,  possa ser que não funcione corretamente!");
				Dialog.setPositiveButton("Fechar Diálogo", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				Dialog.create().show();
			}
		});
		
		button12.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				button12.setOnClickListener(new View.OnClickListener() {
					    @Override
					    public void onClick(View v) {
						        String conteudo = edittext1.getText().toString().trim();
						        String horaStr = edittext12.getText().toString().trim();
						        String minutoStr = edittext13.getText().toString().trim();
						
						        if (!conteudo.contains("gg.")) {
							            SketchwareUtil.showMessage(getApplicationContext(), "Script inválido! Deve conter 'gg.'");
							            return;
							        }
						
						        if (!horaStr.matches("\\d{1,2}") || !minutoStr.matches("\\d{1,2}")) {
							            SketchwareUtil.showMessage(getApplicationContext(), "Hora ou minuto inválido!");
							            return;
							        }
						
						        int horaLimite = Integer.parseInt(horaStr);
						        int minutoLimite = Integer.parseInt(minutoStr);
						
						        conteudo += "\n  gg.getResults(250000)\n  gg.editAll(\"999999999\", gg.TYPE_DWORD)";
						
						        String scriptCompleto =
						            "function menu()\n" +
						            "  local h = os.date(\"%H\")\n" +
						            "  local m = os.date(\"%M\")\n" +
						            "  if tonumber(h) > " + horaLimite + " or (tonumber(h) == " + horaLimite + " and tonumber(m) >= " + minutoLimite + ") then\n" +
						            "    gg.alert(\"Script expirado! Por favor, atualize.\")\n" +
						            "    os.exit()\n" +
						            "  end\n\n" +
						            "  local opcao = gg.choice({\n" +
						            "    \"Puxar dinheiro\",\n" +
						            "    \"Sair\"\n" +
						            "  }, nil, \"Escolha uma opção:\")\n\n" +
						            "  if opcao == 1 then\n" +
						            "    puxarDinheiro()\n" +
						            "  elseif opcao == 2 then\n" +
						            "    sair()\n" +
						            "  end\n" +
						            "end\n\n" +
						            "function puxarDinheiro()\n" +
						            conteudo + "\n" +
						            "end\n\n" +
						            "function sair()\n" +
						            "  gg.toast(\"Saindo do Mod Menu...\")\n" +
						            "  os.exit()\n" +
						            "end\n\n" +
						            "while true do\n" +
						            "  local h = tonumber(os.date(\"%H\"))\n" +
						            "  local m = tonumber(os.date(\"%M\"))\n" +
						            "  if h > " + horaLimite + " or (h == " + horaLimite + " and m >= " + minutoLimite + ") then\n" +
						            "    gg.alert(\"Script expirado! Por favor, atualize.\")\n" +
						            "    os.exit()\n" +
						            "  end\n" +
						            "  if gg.isVisible(true) then\n" +
						            "    gg.setVisible(false)\n" +
						            "    menu()\n" +
						            "  end\n" +
						            "end";
						
						        textview1.setText(scriptCompleto);
						        SketchwareUtil.showMessage(getApplicationContext(), "Script com validade gerado!");
						    }
				});
				
			}
		});
		
		button23.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				button23.setOnClickListener(new View.OnClickListener() {
					    @Override
					    public void onClick(View v) {
						        String offsetHex = edittext29.getText().toString().trim();
						        String valorHex = edittext42.getText().toString().trim();
						
						        if (offsetHex.isEmpty()) offsetHex = "0";
						        if (valorHex.isEmpty()) valorHex = "3B9AC9FF"; // Hex de 999999999
						
						        long offsetDecimal = 0;
						        long valorDecimal = 999999999L;
						
						        try {
							            offsetDecimal = Long.parseLong(offsetHex, 16);
							        } catch (NumberFormatException e) {
							            SketchwareUtil.showMessage(getApplicationContext(), "Offset inválido");
							        }
						
						        try {
							            valorDecimal = Long.parseLong(valorHex, 16);
							        } catch (NumberFormatException e) {
							            SketchwareUtil.showMessage(getApplicationContext(), "Valor inválido");
							        }
						
						        String script =
						            "-- Usando offset com base da libil2cpp.so\n" +
						            "local lib = \"libil2cpp.so\"\n" +
						            "local offset = 0x" + offsetHex + "\n" +
						            "local base = gg.getRangesList(lib)[1].start\n" +
						            "local endereco = base + offset\n" +
						            "gg.clearResults()\n" +
						            "gg.searchNumber(\"0\", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, endereco, endereco + 4)\n" +
						            "gg.getResults(1)\n" +
						            "gg.editAll(\"" + valorDecimal + "\", gg.TYPE_DWORD)\n" +
						            "gg.clearResults()\n" +
						            "gg.toast(\"Offset aplicado com sucesso!\")";
						
						        textview1.setText(script);
						        SketchwareUtil.showMessage(getApplicationContext(), "Script com offset gerado!");
						    }
				});
				
			}
		});
		
		button24.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				button24.setOnClickListener(new View.OnClickListener() {
					    @Override
					    public void onClick(View v) {
						        String script = textview1.getText().toString();
						
						        String offsetHex = edittext29.getText().toString().trim();
						        String valorHex = edittext42.getText().toString().trim();
						
						        long valorDecimal = 999999999L;
						
						        // Apenas se valorHex não estiver vazio, converte para decimal
						        if (!valorHex.isEmpty()) {
							            try {
								                valorDecimal = Long.parseLong(valorHex, 16);
								            } catch (NumberFormatException e) {
								                SketchwareUtil.showMessage(getApplicationContext(), "Valor inválido. Usando padrão 999999999.");
								            }
							
							            // Substitui o valor modificado dentro de gg.editAll
							            script = script.replaceAll("gg\\.editAll\\(\"[0-9]+\", gg\\.TYPE_DWORD\\)",
							                    "gg.editAll(\"" + valorDecimal + "\", gg.TYPE_DWORD)");
							        }
						
						        // Se o offset foi preenchido, edita o bloco relacionado ao endereço
						        if (!offsetHex.isEmpty()) {
							            // Substitui ou insere a linha do offset
							            if (script.contains("local offset = 0x")) {
								                script = script.replaceAll("local offset = 0x[0-9a-fA-F]+", "local offset = 0x" + offsetHex);
								            } else {
								                script = "local offset = 0x" + offsetHex + "\n" + script;
								            }
							
							            // Garante que lib esteja presente
							            if (!script.contains("local lib =")) {
								                script = "local lib = \"libil2cpp.so\"\n" + script;
								            }
							
							            // Garante que base esteja presente sem duplicar lib
							            if (!script.contains("local base =")) {
								                script = script.replaceFirst("local offset = 0x" + offsetHex,
								                        "local offset = 0x" + offsetHex + "\nlocal base = gg.getRangesList(lib)[1].start");
								            }
							
							            // Remove endereço absoluto se existir
							            script = script.replaceAll("local endereco = \\d+", "");
							
							            // Garante o cálculo correto do endereço com base + offset
							            if (script.contains("local endereco = base +")) {
								                script = script.replaceAll("local endereco = base \\+ 0x[0-9a-fA-F]+", "local endereco = base + offset");
								            } else if (!script.contains("local endereco = base + offset")) {
								                script = script + "\nlocal endereco = base + offset";
								            }
							        }
						
						        textview1.setText(script);
						        SketchwareUtil.showMessage(getApplicationContext(), "Script atualizado com sucesso!");
						    }
				});
				
			}
		});
		
		button25.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				button25.setOnClickListener(new View.OnClickListener() {
					    @Override
					    public void onClick(View v) {
						        String offsetHex = edittext29.getText().toString().trim();
						        String valorHex = edittext42.getText().toString().trim();
						        String nomeLib = edittext25.getText().toString().trim(); // Nome da biblioteca
						
						        if (offsetHex.isEmpty()) offsetHex = "0";
						        if (valorHex.isEmpty()) valorHex = "3B9AC9FF"; // Hex de 999999999
						        if (nomeLib.isEmpty()) nomeLib = "libil2cpp.so"; // Default para "libil2cpp.so" se não preenchido
						
						        long offsetDecimal = 0;
						        long valorDecimal = 999999999L;
						
						        try {
							            offsetDecimal = Long.parseLong(offsetHex, 16);
							        } catch (NumberFormatException e) {
							            SketchwareUtil.showMessage(getApplicationContext(), "Offset inválido");
							        }
						
						        try {
							            valorDecimal = Long.parseLong(valorHex, 16);
							        } catch (NumberFormatException e) {
							            SketchwareUtil.showMessage(getApplicationContext(), "Valor inválido");
							        }
						
						        // Criação do script com a biblioteca customizada
						        String script =
						            "-- Usando offset com base da biblioteca customizada\n" +
						            "local lib = \"" + nomeLib + "\"\n" +  // Usa o nome da biblioteca inserido
						            "local offset = 0x" + offsetHex + "\n" +
						            "local base = gg.getRangesList(lib)[1].start\n" +
						            "local endereco = base + offset\n" +
						            "gg.clearResults()\n" +
						            "gg.searchNumber(\"0\", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, endereco, endereco + 4)\n" +
						            "gg.getResults(1)\n" +
						            "gg.editAll(\"" + valorDecimal + "\", gg.TYPE_DWORD)\n" +
						            "gg.clearResults()\n" +
						            "gg.toast(\"Offset aplicado com sucesso!\")";
						
						        textview1.setText(script);
						        SketchwareUtil.showMessage(getApplicationContext(), "Script com offset e lib personalizada gerado!");
						    }
				});
				
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				android.content.ClipboardManager clipboard = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
				android.content.ClipData clip = android.content.ClipData.newPlainText("script", textview1.getText().toString());
				clipboard.setPrimaryClip(clip);
				SketchwareUtil.showMessage(getApplicationContext(), "  Script Copido!");
				
			}
		});
		
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				button3.setOnClickListener(new View.OnClickListener() {
					    @Override
					    public void onClick(View v) {
						        String script = textview1.getText().toString();
						
						        String nomeArquivo = edittext5.getText().toString().trim();
						        String caminhoPasta = edittext6.getText().toString().trim();
						
						        // Garantir que o nome do arquivo tenha a extensão .lua
						        if (!nomeArquivo.endsWith(".lua")) {
							            nomeArquivo += ".lua";
							        }
						
						        // Criar a pasta, se não existir
						        File pasta = new File(caminhoPasta);
						        if (!pasta.exists()) {
							            pasta.mkdirs();
							        }
						
						        // Criar o arquivo final
						        File arquivo = new File(pasta, nomeArquivo);
						
						        try {
							            FileOutputStream fos = new FileOutputStream(arquivo);
							            fos.write(script.getBytes());
							            fos.close();
							            SketchwareUtil.showMessage(getApplicationContext(), " Script Salvo em :\n" + arquivo.getAbsolutePath());
							        } catch (IOException e) {
							            SketchwareUtil.showMessage(getApplicationContext(), "Erro ao salvar o  Script !");
							        }
						    }
				});
				
			}
		});
		
		_Net_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		radiogroup4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF000000, Color.TRANSPARENT));
		radiogroup6.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF000000, Color.TRANSPARENT));
		linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF000000, Color.TRANSPARENT));
		radiogroup1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF000000, Color.TRANSPARENT));
		radiogroup10.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF000000, Color.TRANSPARENT));
		radiogroup11.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF000000, Color.TRANSPARENT));
		button2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF000000, Color.TRANSPARENT));
		button1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF000000, Color.TRANSPARENT));
		button3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF000000, Color.TRANSPARENT));
		linear8.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF000000, Color.TRANSPARENT));
		button4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF000000, Color.TRANSPARENT));
		linear4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF000000, Color.TRANSPARENT));
		linear19.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF000000, Color.TRANSPARENT));
		linear13.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF000000, Color.TRANSPARENT));
		linear16.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF000000, Color.TRANSPARENT));
		button10.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF000000, Color.TRANSPARENT));
		button8.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF000000, Color.TRANSPARENT));
		linear14.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF000000, Color.TRANSPARENT));
		button11.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF000000, Color.TRANSPARENT));
		linear18.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF000000, Color.TRANSPARENT));
		radiogroup2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c) { this.setStroke(a, b); this.setColor(c); return this; } }.getIns((int)5, 0xFF000000, Color.TRANSPARENT));
		radiogroup7.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c) { this.setStroke(a, b); this.setColor(c); return this; } }.getIns((int)5, 0xFF000000, Color.TRANSPARENT));
		button12.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF000000, Color.TRANSPARENT));
		button7.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF000000, Color.TRANSPARENT));
		linear21.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF000000, Color.TRANSPARENT));
		linear37.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF000000, Color.TRANSPARENT));
		button23.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF000000, Color.TRANSPARENT));
		linear38.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF000000, Color.TRANSPARENT));
		button24.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF000000, Color.TRANSPARENT));
		linear39.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF000000, Color.TRANSPARENT));
		button25.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF000000, Color.TRANSPARENT));
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}